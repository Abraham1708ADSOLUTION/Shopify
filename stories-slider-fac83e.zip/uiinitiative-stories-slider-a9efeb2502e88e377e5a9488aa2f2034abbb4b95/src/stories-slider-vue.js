import StoriesSlider from './vue/StoriesSlider.vue';
import Stories from './vue/Stories.vue';
import Story from './vue/Story.vue';

export { StoriesSlider, Stories, Story };
