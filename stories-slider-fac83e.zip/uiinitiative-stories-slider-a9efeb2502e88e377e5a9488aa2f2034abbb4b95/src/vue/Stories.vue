<template>
  <div class="swiper-slide">
    <div class="swiper">
      <div class="swiper-wrapper">
        <slot />
      </div>
    </div>
  </div>
</template>
