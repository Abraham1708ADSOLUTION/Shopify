UI Initiative Regular License

Copyright (c) 2023 UI Initiative, https://uiinitiative.com

License gives you as a customer non-exclusive & non-transferable right to use the product, in this case is the "Shutters Slider" (further "Item")

1. We do not limit the number of Item’s copies you are going to use. Using one Item you can create, for example, even 100 web-sites or applications.
2. You can use the Item by itself or it’s also possible to apply it in other project you work at.
3. You can use the Item for your own purpose as well as for your clients.
4. You can use the Item in commercial projects.
5. You can reproduce the Item:

   - on a web-site, app or as a web-site, app
   - as a printed variant
   - in digital (electronic) format (as a presentation or an e-book)
   - in video products

6. All photos and images used in Item for demonstration are property of their respective owners.
7. You are not allowed to sell, resell, license or give the Item free (any way) without our written consent. Please, do not offer to do it to any person.
8. You also do not have the right to use the Item in a project for selling (for example, in other templates, scripts, graphics and so on).
9. It’s prohibited to rework / redesign / reproduce the Item (i.e. to rename it or change graphics & so on) and after this to sell it as your own.
10. In spite of reselling limitation you could claim money for the Item from your client.
11. If the Item (the whole Item or its parts) is created with materials used by GNU General Public License (GPL) (or some other license) it means you should follow all the terms of the license using the Item.
